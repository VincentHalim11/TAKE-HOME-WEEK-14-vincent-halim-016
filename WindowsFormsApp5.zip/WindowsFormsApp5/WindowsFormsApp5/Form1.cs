﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        MySqlConnection connect;
        MySqlCommand command;
        MySqlDataAdapter adapter;
        DataTable dt = new DataTable();
        DataTable dt2 = new DataTable();
        DataTable isi = new DataTable(); 
        string query;
        int  id;
        
        

        private void Form1_Load(object sender, EventArgs e)
        {
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "yyyy-MM-dd";

            connect = new MySqlConnection("server = localhost; uid = root; pwd = prodotaggwp1; database = premier_league");
            connect.Open();
            connect.Close();
            query = "select * from team";
            command = new MySqlCommand(query, connect);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(dt);
            adapter.Fill(dt2);
            cb_home.DataSource = dt;
            cb_home.DisplayMember = "team_name";
            cb_home.ValueMember = "team_id";
            cb_home.Text = " ";
        
            cb_away.DataSource = dt2;
            cb_away.DisplayMember = "team_name";
            cb_away.ValueMember = "team_id";        
            cb_away.Text = " ";

            isi.Columns.Add("minute");
            isi.Columns.Add("team");
            isi.Columns.Add("player");
            isi.Columns.Add("type");

            dgv_detail.DataSource = isi;

        }

        private void cb_home_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cb_home.Text == cb_away.Text)
            {
                MessageBox.Show("Tidak bole sama");
            }
            if (cb_home != null & cb_away != null)
            {
                cb_team.Items.Clear();
                cb_team.Items.Add(cb_home.Text);
                cb_team.Items.Add(cb_away.Text);
            }

           
        }

        private void cb_away_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_away.Text == cb_home.Text)
            {
                MessageBox.Show("Tidak bole sama");
            }
            if (cb_home != null & cb_away != null)
            {
                cb_team.Items.Clear();
                cb_team.Items.Add(cb_home.Text);
                cb_team.Items.Add(cb_away.Text);
            }
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable player = new DataTable();
            string query = "select player_name from player left join team on team.team_name = '" + cb_team.Text + "' where player.team_id = team.team_id AND status = 1 group by player_name";
            command = new MySqlCommand(query, connect);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(player);
            cb_player.DataSource = player;
            cb_player.DisplayMember = "player";
            cb_player.ValueMember = "player_name";
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if (txt_menit.Text == "" || cb_team.Text == "" || cb_player.Text == "" || cb_type.Text == "")
            {
                MessageBox.Show("ada yang kosong");
            }
            else
            {

                isi.Rows.Add(txt_menit.Text, cb_team.Text, cb_player.Text, cb_type.Text);
                txt_menit.Text = "";
                cb_team.Text = "";
                cb_player.Text = "";
                cb_type.Text = "";
            }
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {

            //blom selesai
            DataTable masuk = new DataTable();
            string query = "INSERT ";
            command = new MySqlCommand(query, connect);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(masuk);
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            foreach(DataGridViewRow dr in dgv_detail.SelectedRows)
            {
                dgv_detail.Rows.RemoveAt(dr.Index);
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

            id = dateTimePicker1.Value.Year;
            txt_matchid.Text = id.ToString();
        }



        private void txt_menit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

        }



        //connect = new MySqlConnection("server = localhost; uid = root; pwd = prodotaggwp1; database = premier_league");
        // connect.Open();
        //connect.Close();
        //query = "select * from team";
        //command = new MySqlCommand(query, connect);
        // adapter = new MySqlDataAdapter(command);
        // adapter.Fill(dt);
        //adapter.Fill(dt2);
        //cb_home.DataSource = dt;
        //cb_home.DisplayMember = "team_name";
        //cb_home.ValueMember = "team_id";
        //cb_home.Text = " ";



        //cb_away.DataSource = dt2;
        //cb_away.DisplayMember = "team_name";
        //cb_away.ValueMember = "team_id";
        //cb_away.Text = " ";

    }
}
